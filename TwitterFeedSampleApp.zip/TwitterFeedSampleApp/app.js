var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var routes = require('./routes/index');
var users = require('./routes/users');

var app = express();

var url = require('url');

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));


module.exports = app;

app.use(express.static('public'));

var server = app.listen(3000, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})

app.get('/getFeed', function (req, res) {
   console.log("got new request ");
   var url_parts = url.parse(req.url,true);   
   var $tag = url_parts.query.tag;
   console.log("request parameter:  "+$tag);
   createSocketIO($tag);
   res.sendFile( __dirname + "/"+ "index.html" );
   
})


var currDataFeed;
var dataFeed = "";
const io = require('socket.io')(server);
//const io = socketIO(server);


function createSocketIO($tag) {
    io.on('connection', (socket) => {
      console.log('Client connected');
      socket.on('disconnect', () => console.log('Client disconnected'));  
    });
    setInterval(() => io.emit('time', new Date().toTimeString()), 6000);
    getTwitterFeed($tag);

    setInterval(() => io.emit('feed', currDataFeed, 2000));

}


function getTwitterFeed($tag){

var Twitter = require('twitter');
var TwitterStreamChannels = require('twitter-stream-channels');

var credentials = {consumer_key: '8UDGiLipQxz7fOtcU2uC9ELDZ',
  consumer_secret: 'pZyN7RUYo75jLPNax8fhQ1meYwn4akmg3xrz1LWpLtOx1smYxV',
  access_token: '785362773513383936-YYbx9ljV69YdwORakioOrzlLwXBHb1r',
  access_token_secret: '65W4aA6ekNXiiQhslsoWBwovAlQM0R3zsaukEnOQdwhq0'
};

var client = new TwitterStreamChannels(credentials);
 
/*var channels = {
    "languages" : ['javascript','php','java','python','perl'],
    "js-frameworks" : ['angularjs','jquery','backbone','emberjs'],
    "web" : ['javascript','nodejs','html5','css','angularjs'],
    "info" : ['iphone']
};*/

var channels = {
    "languages" : ['javascript','php','java','python','perl'],
    "js-frameworks" : ['angularjs','jquery','backbone','emberjs'],
    "web" : ['javascript','nodejs','html5','css','angularjs'],
    "info" : []
};

channels.info[0] = $tag;
 
var stream = client.streamChannels({track:channels});
 

stream.on('channels/info',function(tweet){
    //console.log('>>>INFO: ',tweet);
    if(tweet.lang === 'en') {
      currDataFeed = dataFeed+"\n"+String(tweet.text);
      dataFeed = currDataFeed;
    }
});

setTimeout(function(){
    stream.stop();//closes the stream connected to Twitter 
    console.log('>stream closed after 10 seconds');
},30000);

}